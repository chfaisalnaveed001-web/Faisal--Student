# **App Name**: Faisal Student Portal

## Core Features:

- Secure Gateway: Password-protected administrative entry point using 'faisal123' to ensure exclusive access to student records.
- Live Stats Dashboard: An interactive command center showcasing upload counts by category, storage usage charts, and real-time activity tracking.
- Smart Persistence Engine: Handles local data storage using SQLite to manage file metadata, notes, and system settings without requiring cloud accounts.
- AI Study Assistant Tool: A generative AI tool that explains complex code, summarizes uploaded PDF materials, and provides step-by-step exam preparation help.
- Universal File Explorer: A sophisticated table with instant search, multi-factor filtering, and support for dragging and dropping source code or document files.
- Academic Compute Suite: Integrated calculators for specialized student needs including Scientific operations and localized GPA/CGPA computation.
- Persistent Knowledge Notes: A rich-text note-taking system featuring auto-save functionality and a dedicated search tool for rapid retrieval of study material.

## Style Guidelines:

- Primary color: Deep Indigo (#6366F1), reflecting a professional and intelligent academic atmosphere.
- Background color: Deep Slate Midnight (#0F172A), designed for a premium dark-themed aesthetic.
- Accent color: Vibrant Cyan (#22D3EE), providing high contrast for highlights, progress bars, and call-to-action buttons.
- Headline font: 'Space Grotesk' (sans-serif) for a modern, tech-forward scientific look; Body font: 'Inter' (sans-serif) for maximum legibility in lists and data tables.
- Code font: 'Source Code Pro' (monospace) for displaying academic programming projects and snippets.
- Glassmorphism architecture featuring blurred backdrop sidebars, rounded container cards, and fixed-position navigation for mobile responsiveness.
- Micro-interactions and smooth Framer Motion transitions during subject navigation and file upload success states.