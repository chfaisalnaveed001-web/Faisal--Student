import { config } from 'dotenv';
config();

import '@/ai/flows/ai-code-assistant.ts';
import '@/ai/flows/ai-study-explainer-flow.ts';
import '@/ai/flows/ai-document-summarizer.ts';