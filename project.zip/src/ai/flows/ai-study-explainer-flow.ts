'use server';
/**
 * @fileOverview An AI assistant that explains difficult concepts and answers study questions.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const AiStudyExplainerInputSchema = z.object({
  question: z.string().describe('The study question or difficult concept to be explained.'),
});
export type AiStudyExplainerInput = z.infer<typeof AiStudyExplainerInputSchema>;

const AiStudyExplainerOutputSchema = z.object({
  explanation: z.string().describe('A clear and concise explanation.'),
});
export type AiStudyExplainerOutput = z.infer<typeof AiStudyExplainerOutputSchema>;

export async function aiStudyExplainer(input: AiStudyExplainerInput): Promise<AiStudyExplainerOutput> {
  const { output } = await aiStudyExplainerPrompt(input);
  if (!output) throw new Error('AI failed to generate an explanation');
  return output;
}

const aiStudyExplainerPrompt = ai.definePrompt({
  name: 'aiStudyExplainerPrompt',
  input: { schema: AiStudyExplainerInputSchema },
  output: { schema: AiStudyExplainerOutputSchema },
  prompt: `You are an AI Study Assistant. Provide a clear, concise, and easy-to-understand explanation for the student's question.

Question: {{{question}}}`,
});
