'use server';
/**
 * @fileOverview An AI agent for summarizing PDF documents.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SummarizePdfInputSchema = z.object({
  pdfDataUri: z
    .string()
    .describe(
      "A PDF document as a data URI."
    ),
});
export type SummarizePdfInput = z.infer<typeof SummarizePdfInputSchema>;

const SummarizePdfOutputSchema = z.object({
  summary: z.string().describe('The summarized content of the PDF.'),
});
export type SummarizePdfOutput = z.infer<typeof SummarizePdfOutputSchema>;

export async function summarizePdf(
  input: SummarizePdfInput
): Promise<SummarizePdfOutput> {
  const {output} = await summarizePdfPrompt(input);
  if (!output) throw new Error('AI failed to summarize the PDF');
  return output;
}

const summarizePdfPrompt = ai.definePrompt({
  name: 'summarizePdfPrompt',
  input: {schema: SummarizePdfInputSchema},
  output: {schema: SummarizePdfOutputSchema},
  prompt: `Summarize the following PDF document academic content. Extract main points and findings.

PDF Document: {{media url=pdfDataUri}}`,
});
