'use server';
/**
 * @fileOverview An AI assistant that helps students understand, debug, and analyze programming code.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const AssistCodeInputSchema = z.object({
  code: z.string().describe('The programming code to be analyzed.'),
  language: z.string().optional().describe('The programming language of the code.'),
});
export type AssistCodeInput = z.infer<typeof AssistCodeInputSchema>;

const AssistCodeOutputSchema = z.object({
  explanation: z.string().describe('A detailed explanation of the code.'),
  debugSuggestions: z.string().describe('Suggestions for debugging or improving the code.'),
  algorithmBreakdown: z.string().describe('A breakdown of the algorithms or logic used in the code.'),
});
export type AssistCodeOutput = z.infer<typeof AssistCodeOutputSchema>;

export async function assistCode(input: AssistCodeInput): Promise<AssistCodeOutput> {
  const { output } = await assistCodePrompt(input);
  if (!output) throw new Error('AI failed to generate a response');
  return output;
}

const assistCodePrompt = ai.definePrompt({
  name: 'assistCodePrompt',
  input: { schema: AssistCodeInputSchema },
  output: { schema: AssistCodeOutputSchema },
  prompt: `You are an expert programming assistant. Provide a detailed explanation, debug suggestions, and an algorithm breakdown for the given code.

Code Language: {{{language}}}

Code:
\n\`\`\`\n{{{code}}}\n\`\`\`\n

Please provide your response in the requested structured format.`,
});
