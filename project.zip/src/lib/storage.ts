/**
 * @fileOverview Firebase Firestore management for the Faisal Student Portal.
 */
import { 
  collection, 
  getDocs, 
  doc, 
  setDoc, 
  deleteDoc, 
  query,
  limit
} from 'firebase/firestore';
import { db as firestore } from '@/firebase/config';

export interface Subject {
  id: string;
  name: string;
  color: string;
}

export interface StudentFile {
  id: string;
  name: string;
  subjectId: string;
  category: 'Assignment' | 'Project' | 'Lab Task' | 'Notes';
  description?: string;
  semester?: string;
  uploadDate: string;
  fileType: string;
  fileSize: number;
  data: string;
  storagePath?: string;
  isFavorite?: boolean;
  isPinned?: boolean;
}

export interface Note {
  id: string;
  title: string;
  subjectId: string;
  content: string;
  updatedAt: string;
}

export const db = {
  async getAll<T>(storeName: string): Promise<T[]> {
    try {
      const colRef = collection(firestore, storeName);
      const snapshot = await getDocs(colRef);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any as T));
    } catch (e) {
      console.error(`Error fetching ${storeName}:`, e);
      return [];
    }
  },

  async put(storeName: string, item: any): Promise<void> {
    if (!item.id) throw new Error("Item must have an ID");
    try {
      const docRef = doc(firestore, storeName, item.id);
      await setDoc(docRef, item, { merge: true });
    } catch (e) {
      console.error(`Error saving to ${storeName}:`, e);
      throw e;
    }
  },

  async delete(storeName: string, id: string): Promise<void> {
    try {
      const docRef = doc(firestore, storeName, id);
      await deleteDoc(docRef);
    } catch (e) {
      console.error(`Error deleting from ${storeName}:`, e);
      throw e;
    }
  },

  async clearStore(storeName: string): Promise<void> {
    try {
      const colRef = collection(firestore, storeName);
      const snapshot = await getDocs(colRef);
      const deletePromises = snapshot.docs.map(d => deleteDoc(d.ref));
      await Promise.all(deletePromises);
    } catch (e) {
      console.error(`Error clearing ${storeName}:`, e);
    }
  }
};

export const DEFAULT_SUBJECTS: Subject[] = [
  { id: '1', name: 'Programming Fundamentals', color: '#6366F1' },
  { id: '2', name: 'Object Oriented Programming', color: '#22D3EE' },
  { id: '3', name: 'Data Structures', color: '#8B5CF6' },
  { id: '4', name: 'Database', color: '#10B981' },
  { id: '5', name: 'Operating Systems', color: '#F59E0B' },
  { id: '6', name: 'Digital Logic Design', color: '#EC4899' },
  { id: '7', name: 'Software Engineering', color: '#3B82F6' },
  { id: '8', name: 'AI', color: '#6EE7B7' },
  { id: '9', name: 'Web Development', color: '#F472B6' },
];

export async function initializeDefaults() {
  try {
    const colRef = collection(firestore, 'subjects');
    const q = query(colRef, limit(1));
    const snapshot = await getDocs(q);
    
    if (snapshot.empty) {
      console.log("Initializing default subjects...");
      for (const sub of DEFAULT_SUBJECTS) {
        await db.put('subjects', sub);
      }
    }
  } catch (error) {
    console.error("Failed to initialize default subjects:", error);
  }
}
