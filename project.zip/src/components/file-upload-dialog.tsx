
/**
 * @fileOverview File upload component updated to use Firebase Storage.
 */
'use client';

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Upload, Plus, X, FileIcon, Loader2 } from 'lucide-react';
import { db, Subject, StudentFile } from '@/lib/storage';
import { useToast } from '@/hooks/use-toast';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from '@/firebase/config';

interface FileUploadDialogProps {
  onUploadSuccess: () => void;
  initialCategory?: 'Assignment' | 'Project' | 'Lab Task' | 'Notes';
}

export function FileUploadDialog({ onUploadSuccess, initialCategory = 'Assignment' }: FileUploadDialogProps) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: '',
    subjectId: '',
    category: initialCategory,
    description: '',
    semester: '',
  });
  const [file, setFile] = useState<File | null>(null);

  useEffect(() => {
    async function fetchSubjects() {
      const subs = await db.getAll<Subject>('subjects');
      setSubjects(subs);
    }
    if (open) {
      fetchSubjects();
      setFormData(prev => ({ ...prev, category: initialCategory }));
    }
  }, [open, initialCategory]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!file || !formData.name || !formData.subjectId) {
      toast({ variant: 'destructive', title: 'Missing Info', description: 'Please fill all required fields.' });
      return;
    }

    setLoading(true);

    try {
      const fileId = Math.random().toString(36).substr(2, 9);
      const storagePath = `portal-files/${fileId}-${file.name}`;
      const fileRef = ref(storage, storagePath);

      // Upload to Firebase Storage
      const uploadResult = await uploadBytes(fileRef, file);
      const downloadUrl = await getDownloadURL(uploadResult.ref);

      const newFile: StudentFile = {
        id: fileId,
        name: formData.name,
        subjectId: formData.subjectId,
        category: formData.category,
        description: formData.description,
        semester: formData.semester,
        uploadDate: new Date().toISOString(),
        fileType: file.type || 'application/octet-stream',
        fileSize: file.size,
        data: downloadUrl, // Storage download URL
        storagePath: storagePath
      };

      await db.put('files', newFile);
      toast({ title: 'Success', description: 'File uploaded and secured in cloud storage.' });
      setOpen(false);
      resetForm();
      onUploadSuccess();
    } catch (error) {
      console.error(error);
      toast({ variant: 'destructive', title: 'Error', description: 'Failed to upload to cloud storage.' });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({ name: '', subjectId: '', category: initialCategory, description: '', semester: '' });
    setFile(null);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gradient-primary text-white gap-2 rounded-xl">
          <Upload className="w-4 h-4" />
          Upload File
        </Button>
      </DialogTrigger>
      <DialogContent className="glass border-white/5 text-white sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-headline">Upload New Document</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Name</Label>
            <Input 
              placeholder="Assignment 1 / Project Title" 
              className="bg-white/5 border-white/10" 
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Subject</Label>
              <Select value={formData.subjectId} onValueChange={(val) => setFormData({...formData, subjectId: val})}>
                <SelectTrigger className="bg-white/5 border-white/10">
                  <SelectValue placeholder="Select Subject" />
                </SelectTrigger>
                <SelectContent className="bg-[#1e293b] border-white/10 text-white">
                  {subjects.map(sub => (
                    <SelectItem key={sub.id} value={sub.id}>{sub.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Category</Label>
              <Select value={formData.category} onValueChange={(val) => setFormData({...formData, category: val as any})}>
                <SelectTrigger className="bg-white/5 border-white/10">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent className="bg-[#1e293b] border-white/10 text-white">
                  <SelectItem value="Assignment">Assignment</SelectItem>
                  <SelectItem value="Project">Project</SelectItem>
                  <SelectItem value="Lab Task">Lab Task</SelectItem>
                  <SelectItem value="Notes">Notes</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Description (Optional)</Label>
            <Textarea 
              placeholder="Brief description..." 
              className="bg-white/5 border-white/10 min-h-[80px]" 
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
            />
          </div>

          <div className="space-y-2">
            <Label>File</Label>
            {!file ? (
              <div 
                className="border-2 border-dashed border-white/10 rounded-xl p-8 text-center hover:border-primary/50 transition-all cursor-pointer group"
                onClick={() => document.getElementById('file-upload')?.click()}
              >
                <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground group-hover:text-primary transition-colors" />
                <p className="text-sm text-muted-foreground">Drag & drop or click to upload</p>
                <input type="file" id="file-upload" className="hidden" onChange={handleFileChange} />
              </div>
            ) : (
              <div className="flex items-center justify-between p-3 bg-primary/10 rounded-xl border border-primary/20">
                <div className="flex items-center gap-3">
                  <FileIcon className="w-5 h-5 text-primary" />
                  <span className="text-sm font-medium truncate max-w-[200px]">{file.name}</span>
                </div>
                <Button variant="ghost" size="icon" onClick={() => setFile(null)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => { setOpen(false); resetForm(); }}>Cancel</Button>
          <Button className="gradient-primary" onClick={handleUpload} disabled={loading}>
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Save & Upload'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
