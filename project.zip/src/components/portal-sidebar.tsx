/**
 * @fileOverview Sidebar navigation for the portal.
 */
'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { cn } from '@/lib/utils';
import { 
  LayoutDashboard, 
  FileText, 
  Briefcase, 
  BookOpen, 
  StickyNote, 
  Calculator, 
  Bot, 
  Settings, 
  LogOut,
  GraduationCap
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const navItems = [
  { label: 'Dashboard', icon: LayoutDashboard, href: '/portal/dashboard' },
  { label: 'Assignments', icon: FileText, href: '/portal/assignments' },
  { label: 'Projects', icon: Briefcase, href: '/portal/projects' },
  { label: 'Subjects', icon: BookOpen, href: '/portal/subjects' },
  { label: 'Notes', icon: StickyNote, href: '/portal/notes' },
  { label: 'Calculator', icon: Calculator, href: '/portal/calculator' },
  { label: 'AI Assistant', icon: Bot, href: '/portal/ai' },
  { label: 'Settings', icon: Settings, href: '/portal/settings' },
];

export function PortalSidebar() {
  const pathname = usePathname();
  const router = useRouter();

  const handleLogout = () => {
    localStorage.removeItem('faisal_portal_auth');
    router.push('/login');
  };

  return (
    <div className="w-64 h-full border-r border-white/5 glass flex flex-col p-4">
      <div className="flex items-center gap-3 px-2 mb-8">
        <div className="p-1.5 bg-primary rounded-lg">
          <GraduationCap className="w-5 h-5 text-white" />
        </div>
        <span className="font-headline font-bold text-lg tracking-tight">Faisal Portal</span>
      </div>

      <nav className="flex-1 space-y-1">
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all group",
                isActive 
                  ? "bg-primary text-white shadow-lg shadow-primary/20" 
                  : "text-muted-foreground hover:bg-white/5 hover:text-white"
              )}>
                <item.icon className={cn("w-5 h-5", isActive ? "text-white" : "group-hover:text-primary transition-colors")} />
                <span className="font-medium">{item.label}</span>
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="pt-4 border-t border-white/5">
        <Button 
          variant="ghost" 
          className="w-full justify-start text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-xl px-3"
          onClick={handleLogout}
        >
          <LogOut className="w-5 h-5 mr-3" />
          Logout
        </Button>
      </div>
    </div>
  );
}
