/**
 * @fileOverview Auth guard with resilient persistence check.
 */
'use client';

import { useEffect, useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { initializeDefaults } from '@/lib/storage';

export function AuthGuard({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [authorized, setAuthorized] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const authStatus = localStorage.getItem('faisal_portal_auth');
    if (authStatus === 'true') {
      setAuthorized(true);
    } else {
      setAuthorized(false);
      if (pathname !== '/login') {
        router.push('/login');
      }
    }
  }, [pathname, router]);

  useEffect(() => {
    async function setup() {
      try {
        // Initialize defaults if needed, with a short timeout to prevent hanging UI
        const initPromise = initializeDefaults();
        const timeoutPromise = new Promise((resolve) => setTimeout(resolve, 3000));
        
        // Wait for either init to finish or 3 seconds to pass
        await Promise.race([initPromise, timeoutPromise]);
        setReady(true);
      } catch (error) {
        console.warn("Database initialization deferred", error);
        setReady(true); // Proceed anyway so user can see login/dashboard
      }
    }
    setup();
  }, []);

  if ((!authorized && pathname !== '/login') || !ready) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0F172A]">
        <div className="animate-pulse flex flex-col items-center gap-4 text-white">
          <div className="w-12 h-12 rounded-full border-4 border-primary border-t-transparent animate-spin"></div>
          <span className="text-muted-foreground font-medium">Establishing secure connection...</span>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
