/**
 * @fileOverview Login page for Faisal Student Portal with Password Recovery and enhanced start state.
 */
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Lock, GraduationCap, ShieldCheck, KeyRound, HelpCircle, ArrowLeft, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

type View = 'login' | 'forgot' | 'reset';

export default function LoginPage() {
  const [view, setView] = useState<View>('login');
  const [password, setPassword] = useState('');
  const [luckyNumber, setLuckyNumber] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const { toast } = useToast();

  // On mount, check if user is already authorized
  useEffect(() => {
    const authStatus = localStorage.getItem('faisal_portal_auth');
    if (authStatus === 'true') {
      router.push('/portal/dashboard');
    }
  }, [router]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const storedPassword = localStorage.getItem('portal_custom_password') || 'faisal123';

    if (password === storedPassword) {
      localStorage.setItem('faisal_portal_auth', 'true');
      toast({
        title: 'Welcome Back',
        description: 'Initializing your academic workspace...',
      });
      // Keep loading state to show the "Starting..." overlay
      setTimeout(() => {
        router.push('/portal/dashboard');
      }, 2000);
    } else {
      toast({
        variant: 'destructive',
        title: 'Access Denied',
        description: 'Incorrect password. Please try again.',
      });
      setLoading(false);
    }
  };

  const handleVerifyLuckyNumber = (e: React.FormEvent) => {
    e.preventDefault();
    if (luckyNumber === '0447') {
      setView('reset');
      toast({
        title: 'Identity Verified',
        description: 'Please set your new portal password.',
      });
    } else {
      toast({
        variant: 'destructive',
        title: 'Verification Failed',
        description: 'Incorrect lucky number.',
      });
    }
  };

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 4) {
      toast({
        variant: 'destructive',
        title: 'Invalid Password',
        description: 'Password must be at least 4 characters long.',
      });
      return;
    }
    localStorage.setItem('portal_custom_password', newPassword);
    toast({
      title: 'Password Updated',
      description: 'Your new password has been saved. Please login.',
    });
    setView('login');
    setPassword('');
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden bg-[#0F172A]">
      {/* Starting Overlay */}
      {loading && (
        <div className="fixed inset-0 z-[100] bg-[#0F172A]/90 backdrop-blur-xl flex flex-col items-center justify-center animate-in fade-in duration-500">
          <div className="relative">
            <div className="w-24 h-24 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
            <GraduationCap className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 text-primary" />
          </div>
          <h2 className="mt-8 text-2xl font-headline font-bold text-white tracking-widest uppercase">Starting Portal...</h2>
          <p className="mt-2 text-muted-foreground animate-pulse">Establishing secure connection</p>
        </div>
      )}

      {/* Decorative background elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/20 rounded-full blur-[120px]" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-accent/20 rounded-full blur-[120px]" />

      <div className="w-full max-w-md p-4 animate-fade-in relative z-10">
        <div className="flex flex-col items-center mb-8 gap-3">
          <div className="p-3 bg-primary/10 rounded-2xl border border-primary/20">
            <GraduationCap className="w-10 h-10 text-primary" />
          </div>
          <h1 className="text-3xl font-headline font-bold text-white tracking-tight text-center">Faisal Student Portal</h1>
          <p className="text-muted-foreground">Secure Personal Academic Gateway</p>
        </div>

        <Card className="glass shadow-2xl border-white/5">
          {view === 'login' && (
            <>
              <CardHeader className="space-y-1">
                <CardTitle className="text-xl flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-accent" />
                  Administrative Entry
                </CardTitle>
                <CardDescription>Enter your secure password to access your dashboard.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        type="password"
                        placeholder="Enter portal password"
                        className="pl-10 bg-white/5 border-white/10 focus:border-primary/50 transition-all text-white"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        disabled={loading}
                      />
                    </div>
                  </div>
                  <Button type="submit" className="w-full gradient-primary hover:opacity-90 font-semibold" disabled={loading}>
                    {loading ? (
                      <span className="flex items-center gap-2"><Loader2 className="w-4 h-4 animate-spin" /> Starting...</span>
                    ) : 'Access Portal'}
                  </Button>
                  <Button 
                    type="button" 
                    variant="link" 
                    className="w-full text-xs text-muted-foreground hover:text-accent"
                    onClick={() => setView('forgot')}
                    disabled={loading}
                  >
                    Forgot Password?
                  </Button>
                </form>
              </CardContent>
            </>
          )}

          {view === 'forgot' && (
            <>
              <CardHeader className="space-y-1">
                <CardTitle className="text-xl flex items-center gap-2">
                  <HelpCircle className="w-5 h-5 text-accent" />
                  Account Recovery
                </CardTitle>
                <CardDescription>Enter your personal lucky number to reset password.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleVerifyLuckyNumber} className="space-y-4">
                  <div className="space-y-2">
                    <div className="relative">
                      <KeyRound className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        type="text"
                        placeholder="Enter lucky number"
                        className="pl-10 bg-white/5 border-white/10 focus:border-primary/50 transition-all text-white"
                        value={luckyNumber}
                        onChange={(e) => setLuckyNumber(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button type="button" variant="outline" className="flex-1 border-white/10" onClick={() => setView('login')}>
                      <ArrowLeft className="w-4 h-4 mr-2" /> Back
                    </Button>
                    <Button type="submit" className="flex-1 gradient-primary hover:opacity-90 font-semibold">
                      Verify
                    </Button>
                  </div>
                </form>
              </CardContent>
            </>
          )}

          {view === 'reset' && (
            <>
              <CardHeader className="space-y-1">
                <CardTitle className="text-xl flex items-center gap-2">
                  <Lock className="w-5 h-5 text-accent" />
                  New Password
                </CardTitle>
                <CardDescription>Set a new secure password for your portal.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleResetPassword} className="space-y-4">
                  <div className="space-y-2">
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        type="password"
                        placeholder="Enter new password"
                        className="pl-10 bg-white/5 border-white/10 focus:border-primary/50 transition-all text-white"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <Button type="submit" className="w-full gradient-primary hover:opacity-90 font-semibold">
                    Reset & Save Password
                  </Button>
                </form>
              </CardContent>
            </>
          )}
        </Card>
        
        <p className="mt-8 text-center text-sm text-muted-foreground">
          © {new Date().getFullYear()} Faisal Student Portal. All rights reserved.
        </p>
      </div>
    </div>
  );
}
