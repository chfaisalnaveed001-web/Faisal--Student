/**
 * @fileOverview Portal settings including data management and logout.
 */
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { db } from '@/lib/storage';
import { useToast } from '@/hooks/use-toast';
import { Download, Upload, Shield, Trash2, LogOut } from 'lucide-react';

export default function SettingsPage() {
  const [newPassword, setNewPassword] = useState('');
  const router = useRouter();
  const { toast } = useToast();

  const handleLogout = () => {
    localStorage.removeItem('faisal_portal_auth');
    toast({
      title: 'Logged Out',
      description: 'You have been securely logged out.',
    });
    router.push('/login');
  };

  const handleBackup = async () => {
    const files = await db.getAll('files');
    const subjects = await db.getAll('subjects');
    const notes = await db.getAll('notes');
    
    const data = JSON.stringify({ files, subjects, notes });
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `faisal_portal_backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    toast({ title: 'Backup Created', description: 'Your data has been exported successfully.' });
  };

  const handleReset = async () => {
    if (confirm('DANGER: This will delete ALL your files, notes, and subjects permanently. Are you sure?')) {
      await db.clearStore('files');
      await db.clearStore('subjects');
      await db.clearStore('notes');
      toast({ title: 'Reset Successful', description: 'All data has been wiped.' });
      window.location.reload();
    }
  };

  return (
    <div className="space-y-8 animate-fade-in max-w-2xl mx-auto pb-10">
      <div>
        <h1 className="text-3xl font-headline font-bold">Settings</h1>
        <p className="text-muted-foreground">Manage your portal configuration and security.</p>
      </div>

      <Card className="glass border-white/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-primary" />
            Security
          </CardTitle>
          <CardDescription>Update your administrative access credentials.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>New Portal Password</Label>
            <Input 
              type="password" 
              placeholder="Enter new password" 
              className="bg-white/5 border-white/10"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
            />
          </div>
          <Button variant="secondary" className="w-full" onClick={() => toast({ title: 'Info', description: 'Password reset feature simulated.' })}>
            Update Password
          </Button>
        </CardContent>
      </Card>

      <Card className="glass border-white/5">
        <CardHeader>
          <CardTitle>Data Management</CardTitle>
          <CardDescription>Export your data for backup or clear local storage.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <Button variant="outline" className="flex-1 border-white/10" onClick={handleBackup}>
              <Download className="w-4 h-4 mr-2" />
              Export Backup
            </Button>
            <Button variant="outline" className="flex-1 border-white/10 cursor-not-allowed opacity-50">
              <Upload className="w-4 h-4 mr-2" />
              Import Backup
            </Button>
          </div>
          <Button variant="destructive" className="w-full bg-destructive/10 hover:bg-destructive text-destructive hover:text-white border-destructive/20" onClick={handleReset}>
            <Trash2 className="w-4 h-4 mr-2" />
            Reset All Data
          </Button>
        </CardContent>
      </Card>

      <Card className="glass border-white/5 border-red-500/20">
        <CardHeader>
          <CardTitle className="text-red-400">Exit Portal</CardTitle>
          <CardDescription>Securely end your administrative session.</CardDescription>
        </CardHeader>
        <CardContent>
          <Button 
            variant="ghost" 
            className="w-full justify-center text-red-400 hover:text-red-300 hover:bg-red-400/10 border border-red-400/20"
            onClick={handleLogout}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout from Faisal Portal
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
