/**
 * @fileOverview Notes taking application.
 */
'use client';

import { useState, useEffect } from 'react';
import { db, Note, Subject } from '@/lib/storage';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Plus, 
  Search, 
  Trash2, 
  Save, 
  FileEdit,
  StickyNote
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function NotesPage() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [activeNote, setActiveNote] = useState<Note | null>(null);
  const [search, setSearch] = useState('');
  const { toast } = useToast();

  const fetchNotes = async () => {
    const allNotes = await db.getAll<Note>('notes');
    const allSubs = await db.getAll<Subject>('subjects');
    setNotes(allNotes.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()));
    setSubjects(allSubs);
  };

  useEffect(() => {
    fetchNotes();
  }, []);

  const createNote = async () => {
    const newNote: Note = {
      id: Math.random().toString(36).substr(2, 9),
      title: 'New Note',
      subjectId: subjects[0]?.id || '1',
      content: '',
      updatedAt: new Date().toISOString()
    };
    await db.put('notes', newNote);
    await fetchNotes();
    setActiveNote(newNote);
  };

  const saveNote = async () => {
    if (!activeNote) return;
    const updated = { ...activeNote, updatedAt: new Date().toISOString() };
    await db.put('notes', updated);
    await fetchNotes();
    toast({ title: 'Saved', description: 'Note saved successfully.' });
  };

  const deleteNote = async (id: string) => {
    if (confirm('Delete this note?')) {
      await db.delete('notes', id);
      if (activeNote?.id === id) setActiveNote(null);
      await fetchNotes();
    }
  };

  const filteredNotes = notes.filter(n => 
    n.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="h-[calc(100vh-140px)] flex gap-6 animate-fade-in">
      {/* Sidebar List */}
      <div className="w-80 flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-headline font-bold">Notes</h1>
          <Button size="icon" className="rounded-full gradient-primary" onClick={createNote}>
            <Plus className="w-5 h-5" />
          </Button>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search notes..." 
            className="pl-9 bg-white/5 border-white/10" 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex-1 overflow-y-auto space-y-2 pr-2 scrollbar-hide">
          {filteredNotes.map(note => (
            <div 
              key={note.id}
              onClick={() => setActiveNote(note)}
              className={`p-4 rounded-2xl cursor-pointer transition-all border ${
                activeNote?.id === note.id 
                  ? 'bg-primary/20 border-primary/50' 
                  : 'bg-white/5 border-white/5 hover:bg-white/10'
              }`}
            >
              <h3 className="font-medium truncate">{note.title}</h3>
              <p className="text-xs text-muted-foreground mt-1">
                {new Date(note.updatedAt).toLocaleDateString()}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Editor */}
      <div className="flex-1">
        {activeNote ? (
          <Card className="glass h-full border-white/5 flex flex-col">
            <div className="p-4 border-b border-white/5 flex items-center justify-between">
              <Input 
                className="bg-transparent border-none text-2xl font-headline font-bold focus-visible:ring-0 p-0"
                value={activeNote.title}
                onChange={e => setActiveNote({...activeNote, title: e.target.value})}
              />
              <div className="flex gap-2">
                <Button variant="ghost" size="icon" className="text-destructive" onClick={() => deleteNote(activeNote.id)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
                <Button variant="secondary" size="icon" onClick={saveNote}>
                  <Save className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <div className="flex-1 p-6">
              <Textarea 
                className="w-full h-full bg-transparent border-none focus-visible:ring-0 resize-none text-lg p-0"
                placeholder="Start writing..."
                value={activeNote.content}
                onChange={e => setActiveNote({...activeNote, content: e.target.value})}
              />
            </div>
          </Card>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-muted-foreground glass rounded-3xl border-dashed border-white/10">
            <StickyNote className="w-16 h-16 mb-4 opacity-10" />
            <p>Select a note to read or edit</p>
          </div>
        )}
      </div>
    </div>
  );
}
