/**
 * @fileOverview AI Assistant interface.
 */
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Bot, Code, FileText, HelpCircle, Loader2, Send, Sparkles, Upload } from 'lucide-react';
import { aiStudyExplainer } from '@/ai/flows/ai-study-explainer-flow';
import { assistCode } from '@/ai/flows/ai-code-assistant';
import { summarizePdf } from '@/ai/flows/ai-document-summarizer';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';

export default function AIAssistantPage() {
  const [loading, setLoading] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [result, setResult] = useState<any>(null);
  const [file, setFile] = useState<File | null>(null);
  const { toast } = useToast();

  const handleStudyExplain = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    try {
      const { explanation } = await aiStudyExplainer({ question: prompt });
      setResult({ type: 'study', content: explanation });
    } catch (e) {
      toast({ variant: 'destructive', title: 'AI Error', description: 'Failed to get AI response.' });
    } finally {
      setLoading(false);
    }
  };

  const handleCodeAssist = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    try {
      const output = await assistCode({ code: prompt });
      setResult({ type: 'code', content: output });
    } catch (e) {
      toast({ variant: 'destructive', title: 'AI Error', description: 'Failed to analyze code.' });
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
    } else {
      toast({ variant: 'destructive', title: 'Invalid File', description: 'Please select a valid PDF document.' });
    }
  };

  const handlePdfSummarize = async () => {
    if (!file) return;
    setLoading(true);
    try {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = async () => {
        const base64Data = reader.result as string;
        const { summary } = await summarizePdf({ pdfDataUri: base64Data });
        setResult({ type: 'pdf', content: summary });
      };
    } catch (e) {
      toast({ variant: 'destructive', title: 'AI Error', description: 'Failed to summarize PDF.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in max-w-5xl mx-auto">
      <div className="text-center space-y-2">
        <div className="inline-flex p-3 bg-accent/10 rounded-2xl border border-accent/20 mb-4">
          <Bot className="w-10 h-10 text-accent" />
        </div>
        <h1 className="text-4xl font-headline font-bold text-white">AI Study Assistant</h1>
        <p className="text-muted-foreground text-lg">Your intelligent companion for academics, coding, and exams.</p>
      </div>

      <Card className="glass border-white/5 overflow-hidden">
        <CardContent className="p-0">
          <Tabs defaultValue="study" className="w-full">
            <TabsList className="w-full h-14 rounded-none bg-white/5 border-b border-white/5">
              <TabsTrigger value="study" className="flex-1 gap-2 data-[state=active]:bg-white/5"><HelpCircle className="w-4 h-4" /> Explain Concept</TabsTrigger>
              <TabsTrigger value="code" className="flex-1 gap-2 data-[state=active]:bg-white/5"><Code className="w-4 h-4" /> Debug Code</TabsTrigger>
              <TabsTrigger value="pdf" className="flex-1 gap-2 data-[state=active]:bg-white/5"><FileText className="w-4 h-4" /> Summarize PDF</TabsTrigger>
            </TabsList>
            
            <div className="p-6 space-y-6">
              <TabsContent value="study" className="mt-0 space-y-4">
                <Textarea 
                  placeholder="Ask any academic question or enter a difficult concept..."
                  className="bg-white/5 border-white/10 min-h-[150px] text-lg font-body"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                />
                <div className="flex justify-end gap-3">
                  <Button variant="ghost" onClick={() => { setPrompt(''); setResult(null); }}>Clear</Button>
                  <Button className="gradient-primary gap-2" onClick={handleStudyExplain} disabled={loading || !prompt.trim()}>
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                    Explain Concept
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="code" className="mt-0 space-y-4">
                <Textarea 
                  placeholder="Paste your code snippet (C++, Python, Java...) here..."
                  className="bg-white/5 border-white/10 min-h-[150px] text-lg font-code"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                />
                <div className="flex justify-end gap-3">
                  <Button variant="ghost" onClick={() => { setPrompt(''); setResult(null); }}>Clear</Button>
                  <Button className="gradient-primary gap-2" onClick={handleCodeAssist} disabled={loading || !prompt.trim()}>
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Code className="w-4 h-4" />}
                    Analyze Code
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="pdf" className="mt-0 space-y-4">
                <div 
                  className="border-2 border-dashed border-white/10 rounded-xl p-12 text-center hover:border-primary/50 transition-all cursor-pointer group bg-white/5"
                  onClick={() => document.getElementById('ai-pdf-upload')?.click()}
                >
                  <input type="file" id="ai-pdf-upload" className="hidden" accept=".pdf" onChange={handleFileChange} />
                  {file ? (
                    <div className="flex flex-col items-center gap-2">
                      <FileText className="w-12 h-12 text-primary" />
                      <p className="text-white font-medium">{file.name}</p>
                      <p className="text-xs text-muted-foreground">Click to change file</p>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-2">
                      <Upload className="w-12 h-12 text-muted-foreground group-hover:text-primary transition-colors" />
                      <p className="text-muted-foreground">Select an academic PDF to summarize</p>
                    </div>
                  )}
                </div>
                <div className="flex justify-end gap-3">
                  <Button variant="ghost" onClick={() => { setFile(null); setResult(null); }}>Clear</Button>
                  <Button className="gradient-primary gap-2" onClick={handlePdfSummarize} disabled={loading || !file}>
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                    Summarize Document
                  </Button>
                </div>
              </TabsContent>

              {result && (
                <div className="animate-fade-in space-y-4">
                  <div className="p-1 bg-white/5 rounded-2xl border border-white/10">
                    <div className="bg-[#0f172a] rounded-xl p-6 prose prose-invert max-w-none">
                      {result.type === 'study' || result.type === 'pdf' ? (
                        <div className="whitespace-pre-wrap text-muted-foreground leading-relaxed">
                          {result.content}
                        </div>
                      ) : (
                        <div className="space-y-6">
                          <div>
                            <h3 className="text-primary font-headline text-lg mb-2">Explanation</h3>
                            <p className="text-muted-foreground">{result.content.explanation}</p>
                          </div>
                          <div>
                            <h3 className="text-accent font-headline text-lg mb-2">Debug Suggestions</h3>
                            <p className="text-muted-foreground">{result.content.debugSuggestions}</p>
                          </div>
                          <div>
                            <h3 className="text-purple-400 font-headline text-lg mb-2">Algorithm Breakdown</h3>
                            <p className="text-muted-foreground">{result.content.algorithmBreakdown}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </Tabs>
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <FeatureBox icon={Code} title="Code Analysis" desc="Debug C++, Java, and Python projects with ease." />
        <FeatureBox icon={FileText} title="PDF Summarizer" desc="Quickly grasp the key points of academic papers." />
        <FeatureBox icon={HelpCircle} title="Exam Prep" desc="Ask tricky questions to prepare for your finals." />
      </div>
    </div>
  );
}

function FeatureBox({ icon: Icon, title, desc }: any) {
  return (
    <div className="p-6 glass border-white/5 rounded-2xl space-y-2 hover:border-primary/50 transition-all">
      <div className="p-2 bg-primary/10 rounded-lg w-fit">
        <Icon className="w-5 h-5 text-primary" />
      </div>
      <h3 className="font-headline font-bold text-white">{title}</h3>
      <p className="text-sm text-muted-foreground">{desc}</p>
    </div>
  );
}
