/**
 * @fileOverview Academic Calculator Suite.
 */
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calculator as CalcIcon, Percent, GraduationCap, Grid3X3, Trash2 } from 'lucide-react';

export default function CalculatorPage() {
  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h1 className="text-3xl font-headline font-bold text-white">Academic Compute Suite</h1>
        <p className="text-muted-foreground">Specialized tools for student mathematical needs.</p>
      </div>

      <Tabs defaultValue="basic" className="space-y-6">
        <TabsList className="bg-white/5 border-white/10 p-1">
          <TabsTrigger value="basic" className="gap-2"><CalcIcon className="w-4 h-4" /> Basic</TabsTrigger>
          <TabsTrigger value="gpa" className="gap-2"><GraduationCap className="w-4 h-4" /> GPA Calculator</TabsTrigger>
        </TabsList>

        <TabsContent value="basic" className="animate-fade-in">
          <BasicCalculator />
        </TabsContent>

        <TabsContent value="gpa" className="animate-fade-in">
          <GPACalculator />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function BasicCalculator() {
  const [display, setDisplay] = useState('0');
  
  const handleNum = (char: string) => {
    setDisplay(prev => {
      if (prev === '0' && !['/','*','-','+','.'].includes(char)) return char;
      // Prevent consecutive operators
      const lastChar = prev.slice(-1);
      if (['/','*','-','+'].includes(lastChar) && ['/','*','-','+'].includes(char)) {
        return prev.slice(0, -1) + char;
      }
      return prev + char;
    });
  };

  const handleClear = () => setDisplay('0');
  
  const handleEval = () => {
    try {
      // Basic sanitization: only allow numbers and simple operators
      // For a student portal, this is a reasonable balance
      const result = Function(`'use strict'; return (${display})`)();
      setDisplay(String(Number(result).toFixed(2)).replace(/\.00$/, ''));
    } catch {
      setDisplay('Error');
    }
  };

  return (
    <Card className="glass border-white/5 max-w-xs mx-auto">
      <CardHeader className="bg-white/5 border-b border-white/5 p-4">
        <div className="text-right text-3xl font-code truncate text-white">{display}</div>
      </CardHeader>
      <CardContent className="grid grid-cols-4 gap-2 p-4">
        {['7','8','9','/','4','5','6','*','1','2','3','-','0','.','=','+'].map(char => (
          <Button 
            key={char} 
            variant={['/','*','-','+','='].includes(char) ? 'default' : 'secondary'}
            className={char === '=' ? 'gradient-primary' : 'bg-white/5 hover:bg-white/10'}
            onClick={() => char === '=' ? handleEval() : handleNum(char)}
          >
            {char}
          </Button>
        ))}
        <Button variant="destructive" className="col-span-4 mt-2 bg-destructive/20 hover:bg-destructive text-destructive hover:text-white" onClick={handleClear}>
          Clear All
        </Button>
      </CardContent>
    </Card>
  );
}

function GPACalculator() {
  const [courses, setCourses] = useState([{ grade: '', credits: '' }]);
  const [gpa, setGpa] = useState<number | null>(null);

  const gradePoints: any = { 
    'A+': 4.0, 'A': 4.0, 'A-': 3.7,
    'B+': 3.3, 'B': 3.0, 'B-': 2.7,
    'C+': 2.3, 'C': 2.0, 'C-': 1.7,
    'D+': 1.3, 'D': 1.0, 'F': 0.0 
  };

  const calculate = () => {
    let totalPoints = 0;
    let totalCredits = 0;
    courses.forEach(c => {
      const points = gradePoints[c.grade.toUpperCase().trim()] ?? 0;
      const credits = parseFloat(c.credits) || 0;
      totalPoints += points * credits;
      totalCredits += credits;
    });
    setGpa(totalCredits > 0 ? totalPoints / totalCredits : 0);
  };

  const removeCourse = (index: number) => {
    if (courses.length > 1) {
      setCourses(courses.filter((_, i) => i !== index));
    }
  };

  return (
    <Card className="glass border-white/5 max-w-lg mx-auto">
      <CardHeader>
        <CardTitle className="text-white">Semester GPA Calculator</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          {courses.map((c, i) => (
            <div key={i} className="flex gap-2 items-center">
              <Input 
                placeholder="Grade (A, B...)" 
                className="bg-white/5 border-white/10 text-white"
                value={c.grade}
                onChange={e => {
                  const newC = [...courses];
                  newC[i].grade = e.target.value;
                  setCourses(newC);
                }}
              />
              <Input 
                placeholder="Credits" 
                type="number" 
                className="bg-white/5 border-white/10 text-white"
                value={c.credits}
                onChange={e => {
                  const newC = [...courses];
                  newC[i].credits = e.target.value;
                  setCourses(newC);
                }}
              />
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive shrink-0" onClick={() => removeCourse(i)}>
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="flex-1 border-white/10" onClick={() => setCourses([...courses, { grade: '', credits: '' }])}>
            Add Course
          </Button>
          <Button className="flex-1 gradient-primary" onClick={calculate}>Calculate GPA</Button>
        </div>
        
        {gpa !== null && (
          <div className="text-center p-6 bg-primary/10 rounded-2xl border border-primary/20 animate-fade-in">
            <p className="text-sm text-muted-foreground mb-1 uppercase tracking-wider font-semibold">Your Estimated GPA</p>
            <p className="text-5xl font-headline font-bold text-primary">{gpa.toFixed(2)}</p>
            <p className="text-xs text-muted-foreground mt-2">Based on {courses.length} courses</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
