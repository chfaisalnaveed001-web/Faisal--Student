
/**
 * @fileOverview Projects page.
 */
'use client';

import { useState, useEffect, useCallback } from 'react';
import { db, StudentFile, Subject } from '@/lib/storage';
import { FileUploadDialog } from '@/components/file-upload-dialog';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Briefcase, Download, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function ProjectsPage() {
  const [files, setFiles] = useState<StudentFile[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [search, setSearch] = useState('');
  const { toast } = useToast();

  const fetchFiles = useCallback(async () => {
    const allFiles = await db.getAll<StudentFile>('files');
    const allSubjects = await db.getAll<Subject>('subjects');
    setFiles(allFiles.filter(f => f.category === 'Project'));
    setSubjects(allSubjects);
  }, []);

  useEffect(() => {
    fetchFiles();
  }, [fetchFiles]);

  const handleDownload = (file: StudentFile) => {
    const link = document.createElement('a');
    link.href = file.data;
    link.download = file.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this project file?')) {
      await db.delete('files', id);
      toast({ title: 'Deleted', description: 'Project file removed.' });
      fetchFiles();
    }
  };

  const filtered = files.filter(f => f.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-headline font-bold">Academic Projects</h1>
          <p className="text-muted-foreground">Showcase your coding and research projects.</p>
        </div>
        <FileUploadDialog onUploadSuccess={fetchFiles} initialCategory="Project" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map(file => (
          <Card key={file.id} className="glass border-white/5 hover:border-accent/50 transition-all group overflow-hidden">
            <CardHeader className="relative h-32 bg-gradient-to-br from-primary/20 to-accent/10">
              <Briefcase className="absolute top-4 right-4 w-8 h-8 opacity-10" />
              <div className="absolute bottom-4 left-4">
                <CardTitle className="truncate max-w-[200px]">{file.name}</CardTitle>
                <CardDescription className="text-white/70">
                  {subjects.find(s => s.id === file.subjectId)?.name || 'Subject'}
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <p className="text-sm text-muted-foreground line-clamp-2">
                {file.description || 'No description provided for this project.'}
              </p>
              <div className="flex gap-2">
                <Button variant="outline" className="flex-1 border-white/10" onClick={() => handleDownload(file)}>
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
                <Button variant="ghost" size="icon" className="text-destructive" onClick={() => handleDelete(file.id)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
        {filtered.length === 0 && (
          <div className="col-span-full py-20 text-center text-muted-foreground">
             <p>No projects found. Time to build something great!</p>
          </div>
        )}
      </div>
    </div>
  );
}
