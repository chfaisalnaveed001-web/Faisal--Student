/**
 * @fileOverview Subjects management with individual file view/download/delete and AI bot capabilities.
 */
'use client';

import { useState, useEffect } from 'react';
import { db, Subject, StudentFile } from '@/lib/storage';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Plus, 
  Trash2, 
  FolderOpen, 
  Download, 
  Eye, 
  FileIcon,
  Bot,
  Loader2,
  Sparkles,
  FileText
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useToast } from '@/hooks/use-toast';
import { summarizePdf } from '@/ai/flows/ai-document-summarizer';

export default function SubjectsPage() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [allFiles, setAllFiles] = useState<StudentFile[]>([]);
  const [newSubName, setNewSubName] = useState('');
  const [counts, setCounts] = useState<Record<string, number>>({});
  const { toast } = useToast();

  // File Viewer Dialog State
  const [viewerOpen, setViewerOpen] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [subjectFiles, setSubjectFiles] = useState<StudentFile[]>([]);

  // AI Dialog State
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState<{ title: string; content: string } | null>(null);
  const [aiDialogOpen, setAiDialogOpen] = useState(false);

  const fetchData = async () => {
    const allSubs = await db.getAll<Subject>('subjects');
    const files = await db.getAll<StudentFile>('files');
    
    const countMap: Record<string, number> = {};
    allSubs.forEach(s => {
      countMap[s.id] = files.filter(f => f.subjectId === s.id).length;
    });

    setSubjects(allSubs);
    setAllFiles(files);
    setCounts(countMap);
    
    if (selectedSubject) {
      setSubjectFiles(files.filter(f => f.subjectId === selectedSubject.id));
    }
  };

  useEffect(() => {
    fetchData();
  }, [selectedSubject?.id]);

  const handleAdd = async () => {
    if (!newSubName.trim()) return;
    const newSub: Subject = {
      id: Math.random().toString(36).substr(2, 9),
      name: newSubName,
      color: `hsl(${Math.random() * 360}, 70%, 50%)`
    };
    await db.put('subjects', newSub);
    setNewSubName('');
    fetchData();
    toast({ title: 'Success', description: 'Subject added.' });
  };

  const handleDeleteSubject = async (id: string) => {
    const fileCount = counts[id] || 0;
    if (fileCount > 0) {
      if (!confirm(`Warning: This subject contains ${fileCount} files. Are you sure you want to delete the subject and all related files?`)) {
        return;
      }
      const filesToDelete = allFiles.filter(f => f.subjectId === id);
      for (const file of filesToDelete) {
        await db.delete('files', file.id);
      }
    } else {
      if (!confirm('Are you sure you want to delete this subject?')) return;
    }

    await db.delete('subjects', id);
    toast({ title: 'Deleted', description: 'Subject removed.' });
    fetchData();
  };

  const handleDeleteFile = async (fileId: string) => {
    if (confirm('Are you sure you want to delete this file?')) {
      await db.delete('files', fileId);
      toast({ title: 'Deleted', description: 'File removed.' });
      fetchData();
    }
  };

  const openFileViewer = (subject: Subject) => {
    const files = allFiles.filter(f => f.subjectId === subject.id);
    setSelectedSubject(subject);
    setSubjectFiles(files);
    setViewerOpen(true);
  };

  const handleDownload = (file: StudentFile) => {
    const link = document.createElement('a');
    link.href = file.data;
    link.download = file.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast({ title: 'Downloading', description: `Started download for ${file.name}` });
  };

  const handleAISummarize = async (file: StudentFile) => {
    if (file.fileType !== 'application/pdf') {
      toast({ title: 'AI Assistant', description: 'Currently, AI summarization works best for PDF documents.' });
      return;
    }
    
    setAiLoading(true);
    try {
      const { summary } = await summarizePdf({ pdfDataUri: file.data });
      setAiResult({ title: `AI Summary: ${file.name}`, content: summary });
      setAiDialogOpen(true);
    } catch (e) {
      toast({ variant: 'destructive', title: 'AI Error', description: 'Failed to summarize document.' });
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-headline font-bold text-white">Academic Subjects</h1>
          <p className="text-muted-foreground">Manage your university coursework and modules.</p>
        </div>
        <div className="flex gap-2">
          <Input 
            placeholder="New Subject Name" 
            className="bg-white/5 border-white/10 w-64 text-white" 
            value={newSubName}
            onChange={(e) => setNewSubName(e.target.value)}
          />
          <Button className="gradient-primary text-white" onClick={handleAdd}>
            <Plus className="w-4 h-4 mr-2" />
            Add Subject
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {subjects.map((sub) => (
          <Card key={sub.id} className="glass border-white/5 group relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1.5 h-full" style={{ backgroundColor: sub.color }} />
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg text-white">{sub.name}</CardTitle>
                <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive" onClick={() => handleDeleteSubject(sub.id)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
                <FolderOpen className="w-4 h-4" />
                {counts[sub.id] || 0} Files Recorded
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="secondary" 
                  className="flex-1 text-xs bg-white/5 hover:bg-white/10 text-white" 
                  onClick={() => openFileViewer(sub)}
                >
                  <Eye className="w-3 h-3 mr-2 text-primary" />
                  View Files
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* File Viewer Dialog */}
      <Dialog open={viewerOpen} onOpenChange={setViewerOpen}>
        <DialogContent className="glass border-white/5 text-white sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-2xl font-headline">
              <div className="w-3 h-8 rounded-full" style={{ backgroundColor: selectedSubject?.color }} />
              {selectedSubject?.name} - Files
            </DialogTitle>
          </DialogHeader>

          <div className="py-4">
            {subjectFiles.length > 0 ? (
              <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2 scrollbar-hide">
                {subjectFiles.map((file) => (
                  <div 
                    key={file.id} 
                    className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/5 hover:border-primary/30 transition-all group"
                  >
                    <div className="flex items-center gap-4 min-w-0 flex-1">
                      <div className="p-2 bg-primary/10 rounded-lg shrink-0">
                        <FileIcon className="w-5 h-5 text-primary" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="font-medium text-white truncate pr-4">{file.name}</p>
                        <p className="text-xs text-muted-foreground uppercase">{file.category} • {file.fileType.split('/')[1]}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-accent hover:bg-accent/10"
                        title="AI Bot Analysis"
                        onClick={() => handleAISummarize(file)}
                        disabled={aiLoading}
                      >
                        {aiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Bot className="w-4 h-4" />}
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-primary hover:bg-primary/10"
                        onClick={() => handleDownload(file)}
                        title="Download"
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-muted-foreground hover:text-destructive transition-colors"
                        onClick={() => handleDeleteFile(file.id)}
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-muted-foreground bg-white/5 rounded-2xl border border-dashed border-white/10">
                <FolderOpen className="w-12 h-12 mx-auto mb-4 opacity-10" />
                <p>No files found for this subject yet.</p>
              </div>
            )}
          </div>

          <div className="flex justify-end">
            <Button variant="ghost" onClick={() => setViewerOpen(false)}>Close</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* AI Bot Result Dialog */}
      <Dialog open={aiDialogOpen} onOpenChange={setAiDialogOpen}>
        <DialogContent className="glass border-white/5 text-white sm:max-w-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl font-headline">
              <Sparkles className="w-5 h-5 text-accent" />
              {aiResult?.title}
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <div className="p-4 bg-[#0f172a] rounded-xl border border-white/5 prose prose-invert max-w-none max-h-[50vh] overflow-y-auto scrollbar-hide">
              <p className="text-muted-foreground whitespace-pre-wrap leading-relaxed">
                {aiResult?.content}
              </p>
            </div>
          </div>
          <div className="flex justify-end">
            <Button className="gradient-primary" onClick={() => setAiDialogOpen(false)}>Got it</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
