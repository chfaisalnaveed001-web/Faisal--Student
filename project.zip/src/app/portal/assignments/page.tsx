
/**
 * @fileOverview Assignments page.
 */
'use client';

import { useState, useEffect, useCallback } from 'react';
import { db, StudentFile, Subject } from '@/lib/storage';
import { FileUploadDialog } from '@/components/file-upload-dialog';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { 
  Search, 
  Filter, 
  Download, 
  Trash2, 
  Eye, 
  FileText, 
  MoreVertical
} from 'lucide-react';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';

export default function AssignmentsPage() {
  const [files, setFiles] = useState<StudentFile[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [search, setSearch] = useState('');
  const { toast } = useToast();

  const fetchFiles = useCallback(async () => {
    const allFiles = await db.getAll<StudentFile>('files');
    const allSubjects = await db.getAll<Subject>('subjects');
    setFiles(allFiles.filter(f => f.category === 'Assignment'));
    setSubjects(allSubjects);
  }, []);

  useEffect(() => {
    fetchFiles();
  }, [fetchFiles]);

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this file?')) {
      await db.delete('files', id);
      toast({ title: 'Deleted', description: 'File removed from portal.' });
      fetchFiles();
    }
  };

  const handleDownload = (file: StudentFile) => {
    const link = document.createElement('a');
    link.href = file.data;
    link.download = file.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleView = (file: StudentFile) => {
    const newWindow = window.open();
    if (newWindow) {
      newWindow.document.write(`<iframe src="${file.data}" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>`);
    }
  };

  const filteredFiles = files.filter(f => 
    f.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-headline font-bold">Assignments</h1>
          <p className="text-muted-foreground">Manage and track your university assignments.</p>
        </div>
        <FileUploadDialog onUploadSuccess={fetchFiles} initialCategory="Assignment" />
      </div>

      <Card className="glass border-white/5">
        <CardHeader className="pb-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search assignments..." 
                className="pl-9 bg-white/5 border-white/10" 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <Button variant="outline" className="gap-2 border-white/10 hover:bg-white/5">
              <Filter className="w-4 h-4" />
              Filter
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/10 text-muted-foreground text-sm">
                  <th className="py-4 font-medium px-2">File Name</th>
                  <th className="py-4 font-medium">Subject</th>
                  <th className="py-4 font-medium">Upload Date</th>
                  <th className="py-4 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredFiles.length > 0 ? filteredFiles.map((file) => (
                  <tr key={file.id} className="group hover:bg-white/5 transition-colors">
                    <td className="py-4 px-2">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          <FileText className="w-4 h-4 text-primary" />
                        </div>
                        <span className="font-medium">{file.name}</span>
                      </div>
                    </td>
                    <td className="py-4 text-sm text-muted-foreground">
                      {subjects.find(s => s.id === file.subjectId)?.name || 'Unknown'}
                    </td>
                    <td className="py-4 text-sm text-muted-foreground">
                      {new Date(file.uploadDate).toLocaleDateString()}
                    </td>
                    <td className="py-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="icon" onClick={() => handleView(file)} title="View">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDownload(file)} title="Download">
                          <Download className="w-4 h-4" />
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="bg-[#1e293b] border-white/10 text-white">
                            <DropdownMenuItem className="text-destructive focus:text-destructive focus:bg-destructive/10" onClick={() => handleDelete(file.id)}>
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan={4} className="py-12 text-center text-muted-foreground">
                      No assignments found matching your criteria.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
