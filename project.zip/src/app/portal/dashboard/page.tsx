/**
 * @fileOverview Dashboard page for Faisal Student Portal.
 */
'use client';

import { useEffect, useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  FileText, 
  Briefcase, 
  BookOpen, 
  HardDrive, 
  ArrowUpRight,
  PlusCircle,
  FileIcon
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { db, Subject, StudentFile } from '@/lib/storage';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip as RechartsTooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

export default function DashboardPage() {
  const [stats, setStats] = useState({
    totalFiles: 0,
    totalAssignments: 0,
    totalProjects: 0,
    totalSubjects: 0,
    storageUsed: 0,
    recentFiles: [] as StudentFile[],
    subjectStats: [] as any[],
    categoryStats: [] as any[]
  });

  const loadData = useCallback(async () => {
    const files = await db.getAll<StudentFile>('files');
    const subjects = await db.getAll<Subject>('subjects');
    
    const assignments = files.filter(f => f.category === 'Assignment');
    const projects = files.filter(f => f.category === 'Project');
    const totalSize = files.reduce((acc, f) => acc + f.fileSize, 0);

    // Subject stats for bar chart
    const subStats = subjects.map(s => ({
      name: s.name,
      count: files.filter(f => f.subjectId === s.id).length
    })).filter(s => s.count > 0);

    // Category stats for pie chart
    const catStats = [
      { name: 'Assignments', value: assignments.length, color: '#6366F1' },
      { name: 'Projects', value: projects.length, color: '#22D3EE' },
      { name: 'Lab Tasks', value: files.filter(f => f.category === 'Lab Task').length, color: '#8B5CF6' },
      { name: 'Notes', value: files.filter(f => f.category === 'Notes').length, color: '#10B981' },
    ].filter(c => c.value > 0);

    setStats({
      totalFiles: files.length,
      totalAssignments: assignments.length,
      totalProjects: projects.length,
      totalSubjects: subjects.length,
      storageUsed: totalSize,
      recentFiles: [...files].sort((a, b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime()).slice(0, 5),
      subjectStats: subStats,
      categoryStats: catStats
    });
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-headline font-bold mb-2 text-white">Dashboard</h1>
          <p className="text-muted-foreground text-lg">Welcome back to your academic portal, Faisal.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Total Files" 
          value={stats.totalFiles} 
          icon={FileIcon} 
          color="text-primary" 
          description="Uploaded documents"
        />
        <StatCard 
          title="Assignments" 
          value={stats.totalAssignments} 
          icon={FileText} 
          color="text-accent" 
          description="Task completion"
        />
        <StatCard 
          title="Projects" 
          value={stats.totalProjects} 
          icon={Briefcase} 
          color="text-purple-400" 
          description="Major milestones"
        />
        <StatCard 
          title="Storage" 
          value={formatSize(stats.storageUsed)} 
          icon={HardDrive} 
          color="text-emerald-400" 
          description="Local usage"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 glass border-white/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <BookOpen className="w-5 h-5 text-primary" />
              Uploads by Subject
            </CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            {stats.subjectStats.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.subjectStats}>
                  <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                  <RechartsTooltip 
                    contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }}
                    itemStyle={{ color: '#6366f1' }}
                  />
                  <Bar dataKey="count" fill="#6366f1" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-full text-muted-foreground italic">
                No subject data recorded yet.
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="glass border-white/5">
          <CardHeader>
            <CardTitle className="text-white">File Distribution</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px] flex flex-col items-center">
             {stats.categoryStats.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={stats.categoryStats}
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {stats.categoryStats.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <RechartsTooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px' }} />
                  </PieChart>
                </ResponsiveContainer>
             ) : (
                <div className="flex items-center justify-center h-full text-muted-foreground">
                  No categories to display
                </div>
             )}
          </CardContent>
        </Card>
      </div>

      <Card className="glass border-white/5">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-white">Recent Activity</CardTitle>
          <ArrowUpRight className="w-4 h-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          {stats.recentFiles.length > 0 ? (
            <div className="space-y-4">
              {stats.recentFiles.map((file) => (
                <div key={file.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-white/5 transition-all">
                  <div className="flex items-center gap-4">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <FileIcon className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium text-white">{file.name}</h4>
                      <p className="text-xs text-muted-foreground">
                        {file.category} • {new Date(file.uploadDate).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <span className="text-xs font-code bg-white/10 px-2 py-1 rounded text-muted-foreground uppercase">
                    {file.fileType.split('/')[1] || 'FILE'}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-10 text-muted-foreground">
              <PlusCircle className="w-12 h-12 mx-auto mb-4 opacity-20" />
              <p>No uploads yet. Your portal is ready!</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function StatCard({ title, value, icon: Icon, color, description }: any) {
  return (
    <Card className="glass border-white/5 group hover:border-primary/50 transition-all">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <div className={cn("p-2 rounded-lg bg-muted/50 transition-colors group-hover:bg-primary/10", color)}>
          <Icon className="h-4 w-4" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold font-headline mb-1 text-white">{value}</div>
        <p className="text-xs text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  );
}
