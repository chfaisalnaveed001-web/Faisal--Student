/**
 * @fileOverview Main portal layout with auth protection.
 */
import { AuthGuard } from '@/components/auth-guard';
import { PortalSidebar } from '@/components/portal-sidebar';

export default function PortalLayout({ children }: { children: React.ReactNode }) {
  return (
    <AuthGuard>
      <div className="flex h-screen overflow-hidden bg-[#0F172A] text-white">
        <PortalSidebar />
        <main className="flex-1 overflow-y-auto relative p-6 md:p-10 scrollbar-hide">
          {/* Background Gradients */}
          <div className="fixed top-0 right-0 w-[50%] h-[50%] bg-primary/5 rounded-full blur-[120px] pointer-events-none" />
          <div className="fixed bottom-0 left-64 w-[50%] h-[50%] bg-accent/5 rounded-full blur-[120px] pointer-events-none" />
          
          <div className="relative z-10 max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </AuthGuard>
  );
}
