/**
 * @fileOverview Redirect root to dashboard.
 */
import { redirect } from 'next/navigation';

export default function RootPage() {
  redirect('/portal/dashboard');
}
